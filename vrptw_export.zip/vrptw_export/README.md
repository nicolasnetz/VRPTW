# VRPTW

Model is VRPTW1 from Ch.5 Toth&Vigo, 2014

Implementation made by:
 - Nicolás Netz
 - Lucas Parada